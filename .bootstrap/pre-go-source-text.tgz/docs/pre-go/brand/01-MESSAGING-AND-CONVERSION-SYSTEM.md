# AmtHero24 messaging and conversion system

## Positioning

**Category:** WhatsApp-first personal administrative assistant for Germany.  
**Mental availability:** “I have this letter/appointment/contract problem — I send it to Sam.”  
**Primary value:** reduce uncertainty and turn paperwork into one safe next step.  
**Not:** a general chatbot, government portal, law firm, automated authority or guaranteed outcome service.

## Main headline

> Papierkram in Deutschland. Endlich einfacher.

It is concrete, emotionally relieving and broad enough to cover all six MVP journeys without claiming legal authority.

## Trust sentence

> Sam versteht Briefe, Verträge, Termine und Fristen — und erklärt dir den nächsten Schritt in deiner Sprache.

## One CTA

Before authorization:

> Closed Beta — 5 Plätze, noch nicht geöffnet

After explicit GO only:

> Zur Closed Beta — maximal 5 Plätze

Do not use fake urgency such as a live countdown. “5 places” is factual only while the hard technical capacity is 5.

## Core proof hierarchy

1. **Clarity:** sender/topic/deadline/next step.
2. **Control:** user reviews before acting; no silent execution.
3. **Continuity:** missions, reminders and follow-up.
4. **Language:** de/ar/en/uk/el.
5. **Privacy engineering:** raw content excluded from logs/metrics, transient raw files, aggregate Beta monitoring.
6. **Germany fit:** official correspondence, formal German, appointments, deadlines.

## Claims allowed

- “WhatsApp-first”
- “five supported conversation languages”
- “documents and audio are not retained permanently as raw files after processing”
- “no raw phone numbers, document text or message content in application logs, CI and Beta metrics”
- “admission is fail-closed and capped at five after GO”
- “Sam creates explanations and reviewable drafts”
- “production readiness is continuously checked”
- “designed for everyday administrative tasks in Germany”

## Claims to avoid

- “100% DSGVO-compliant” or “legally certified”
- “we store no phone number anywhere”
- “always correct” or “never misses a deadline”
- “cancels contracts for you” while execution is disabled
- “books appointments” without an enabled confirmed booking integration
- “guaranteed refund”
- “legal advice” or “lawyer replacement”
- “official partner of Germany/WhatsApp/Meta”
- “bank-grade” without a defined audited standard
- unverified customer counts, testimonials, ratings or savings

## Tone

- 70% reassuring companion
- 20% precise expert
- 10% light human warmth

Serious topics use direct, calm language without jokes. Avoid fear-based marketing. The emotional arc is pressure → clarity → controlled action → relief.

## Conversion design

- one primary CTA per viewport zone;
- explain before asking for admission;
- six tools shown as outcomes, not technical features;
- before/after example provides the fastest comprehension;
- FAQ removes fear immediately before the final CTA;
- legal links always visible;
- no form fields before Beta authorization;
- no dark patterns, countdowns, fake scarcity or preselected consent.
